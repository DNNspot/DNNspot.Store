/*
* jQuery Watermark Plugin (v1.0.0)
*   http://updatepanel.net/2009/04/17/jquery-watermark-plugin/
*
* Copyright (c) 2009 Ting Zwei Kuei
*
* Dual licensed under the MIT and GPL licenses.
*   http://www.opensource.org/licenses/mit-license.php
*   http://www.opensource.org/licenses/gpl-3.0.html
*/
(function($) {
    jQuery.fn.updnWatermark = function(options) {
        options = jQuery.extend({}, jQuery.fn.updnWatermark.defaults, options);
        return this.each(function() {
            var $input = jQuery(this);
			// Checks to see if watermark already applied.
            var $watermark = $input.data("updnWatermark");
            // Only create watermark if title attribute exists
            if (!$watermark && this.title) {
				// Inserts a span and set as positioning context
                var $watermark = jQuery("<span/>")
					.addClass(options.cssClass)
                    .insertBefore(this)
                    .hide()
					.bind("show", function() {
                        jQuery(this).children().fadeIn("fast");
                    })
                    .bind("hide", function() {
                        jQuery(this).children().hide();
                    });
				// Positions watermark label relative to positioning context
				jQuery("<label/>").appendTo($watermark)
                    .text(this.title)
                    .attr("for", this.id);
				// Associate input element with watermark plugin.
                $input.data("updnWatermark", $watermark);
            }
			// Hook up blur/focus handlers to show/hide watermark.
            if ($watermark) {
                $input
                    .focus(function(ev) {
                        $watermark.trigger("hide");
                    })
                    .blur(function(ev) {
                        if (!jQuery(this).val()) {
                            $watermark.trigger("show");
                        }
                    });
                // Sets initial watermark state.
                if (!$input.val()) {
                    $watermark.show();
                }
            }
        });
    };
    jQuery.fn.updnWatermark.defaults = {
        cssClass: "updnWatermark"
    };
    jQuery.updnWatermark = {
        attachAll: function(options) {
			jQuery("input:text[title!=''],input:password[title!=''],textarea[title!='']").updnWatermark(options);
        }
    };
})(jQuery);
